<?php

return [
    'site_title' => 'PraveenK Tech Academy',

];
